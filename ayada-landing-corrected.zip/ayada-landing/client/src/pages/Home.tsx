import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Menu, X, MessageCircle, Facebook, Instagram, Mail, Phone, ChevronLeft, ChevronRight, Star } from "lucide-react";
import { useState } from "react";

/**
 * AYADA Landing Page
 * Design Philosophy: Corporativo Moderno y Profesional
 * Colors: Azul Marino (#001F3F), Naranja de Seguridad (#FF6B35), Blanco
 * Typography: Montserrat (display), Poppins (headings), Inter (body)
 */

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState('todos');
  const [modalOpen, setModalOpen] = useState(false);
  const [currentMediaIndex, setCurrentMediaIndex] = useState(0);
  const [formData, setFormData] = useState({ name: '', company: '', email: '', phone: '', service: '', budget: '', message: '' });
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const galleryItems = [
    { id: 1, category: 'proyectos', type: 'image', src: '/manus-storage/1000186487_44a70775.jpg', title: 'Preparación de Área', description: 'Área de trabajo en proceso para punto de reciclaje en eventos' },
    { id: 2, category: 'residuos', type: 'image', src: '/manus-storage/1000184023_80cebdb3.jpg', title: 'Transporte de Residuos', description: 'Equipo profesional transportando residuos' },
    { id: 3, category: 'proyectos', type: 'image', src: '/manus-storage/1000184017_8d7c22dc.jpg', title: 'Área de Trabajo', description: 'Instalación de escenario acorde al concepto y necesidades' },
    { id: 4, category: 'residuos', type: 'image', src: '/manus-storage/1000186559_de671f6b.jpg', title: 'Clasificación de Residuos', description: 'Proceso de clasificación y separación' },
    { id: 6, category: 'limpieza', type: 'video', src: '/manus-storage/1000183385_f3af2ec4.mp4', title: 'Recolección Nocturna', description: 'Servicio de limpieza profesional' },
    { id: 8, category: 'fumigacion', type: 'video', src: '/manus-storage/1000186489_f7eef1b3.mp4', title: 'Video de Fumigación', description: 'Fumigación, tratamiento antiplagas' },
    { id: 9, category: 'residuos', type: 'video', src: '/manus-storage/1000184013_bef83b56.mp4', title: 'Video de Residuos', description: 'Gestión integral de residuos' },
    { id: 10, category: 'proyectos', type: 'video', src: '/manus-storage/1000186488_9ce6b4d0.mp4', title: 'Aplicación Retardante de Palapas', description: 'Aplicación retardante de palapas' },
    { id: 14, category: 'proyectos', type: 'image', src: '/manus-storage/1000183371_6517023a.jpg', title: 'Evento de Reciclaje', description: 'Actividad de conciencia ambiental' },
    { id: 15, category: 'proyectos', type: 'image', src: '/manus-storage/1000183373_7b462802.jpg', title: 'Evento de Reciclaje', description: 'Actividad de conciencia ambiental' },
    { id: 16, category: 'proyectos', type: 'video', src: '/manus-storage/1000183375_3f84a8b7.mp4', title: 'Evento de Reciclaje', description: 'Actividad de conciencia ambiental' },
  ];

  const testimonials = [
    { id: 1, name: 'Carlos Mendez', company: 'Hotel Riviera Resort', text: 'AYADA nos ayudó a cumplir con todas las normativas de seguridad. Excelente servicio y muy profesionales.', rating: 5 },
    { id: 2, name: 'María García', company: 'Restaurante El Cenote', text: 'La capacitación en primeros auxilios fue muy completa. Nuestro equipo se siente más preparado.', rating: 5 },
    { id: 3, name: 'Juan López', company: 'Eco-Resort Tulum', text: 'El tratamiento de retardante para nuestras palapas fue perfecto. Muy recomendados.', rating: 5 },
    { id: 4, name: 'Ana Rodríguez', company: 'Centro de Eventos', text: 'Servicio de fumigación impecable. Muy profesionales y puntuales. Volveremos a contratar.', rating: 5 },
  ];

  const filteredItems = selectedFilter === 'todos' 
    ? galleryItems 
    : galleryItems.filter(item => item.category === selectedFilter);

  const openModal = (index: number) => {
    setCurrentMediaIndex(index);
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
  };

  const nextMedia = () => {
    setCurrentMediaIndex((prev) => (prev + 1) % filteredItems.length);
  };

  const prevMedia = () => {
    setCurrentMediaIndex((prev) => (prev - 1 + filteredItems.length) % filteredItems.length);
  };

  const nextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const handleFormChange = (e: any) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = (e: any) => {
    e.preventDefault();
    const message = `Nuevo contacto de ${formData.name} (${formData.company})\nServicio: ${formData.service}\nPresupuesto: ${formData.budget}\nMensaje: ${formData.message}`;
    window.open(`https://wa.me/529841657527?text=${encodeURIComponent(message)}`, '_blank');
    setFormSubmitted(true);
    setFormData({ name: '', company: '', email: '', phone: '', service: '', budget: '', message: '' });
    setTimeout(() => setFormSubmitted(false), 3000);
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: "smooth" });
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header/Navigation */}
      <header className="sticky top-0 z-50 bg-[#001F3F] text-white shadow-lg">
        <div className="container flex items-center justify-between py-3 md:py-4">
          <div className="flex items-center gap-3">
            <img src="/manus-storage/1000183366_067ac952.jpg" alt="AYADA Logo" className="h-14 w-auto md:h-20 transition-all duration-300" />
          </div>

          {/* Desktop Navigation */}
          {/* Mobile Menu Button - Hidden since nav is now visible */}

          <nav className="flex items-center gap-2 md:gap-8 flex-wrap justify-center md:justify-start">
            <button
              onClick={() => scrollToSection("gestoria")}
              className="hover:text-[#FF6B35] transition-colors text-sm md:text-base"
            >
              Gestoría
            </button>
            <button
              onClick={() => scrollToSection("capacitacion")}
              className="hover:text-[#FF6B35] transition-colors text-sm md:text-base"
            >
              Capacitación
            </button>
            <button
              onClick={() => scrollToSection("fumigacion")}
              className="hover:text-[#FF6B35] transition-colors text-sm md:text-base"
            >
              Fumigación
            </button>
            <button
              onClick={() => scrollToSection("epp")}
              className="hover:text-[#FF6B35] transition-colors text-sm md:text-base"
            >
              EPP
            </button>
            <button
              onClick={() => scrollToSection("limpieza")}
              className="hover:text-[#FF6B35] transition-colors text-sm md:text-base"
            >
              Limpieza
            </button>
          </nav>

          {/* WhatsApp Button */}
          <div className="hidden md:flex items-center gap-4">
            <a
              href="https://wa.me/529841657527"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-[#FF6B35] hover:bg-[#E55A24] px-4 py-2 rounded-lg font-semibold transition-colors"
            >
              <MessageCircle size={18} />
              WhatsApp
            </a>
          </div>

          {/* Mobile Menu Button - Hidden since nav is now visible */}
        </div>

        {/* Mobile Menu - Hidden since nav is now visible */}
        {false && (
          <nav className="hidden bg-[#000F1F] px-4 py-4 space-y-3">
            <button
              onClick={() => scrollToSection("gestoria")}
              className="block w-full text-left py-2 hover:text-[#FF6B35] transition-colors"
            >
              Gestoría
            </button>
            <button
              onClick={() => scrollToSection("capacitacion")}
              className="block w-full text-left py-2 hover:text-[#FF6B35] transition-colors"
            >
              Capacitación
            </button>
            <button
              onClick={() => scrollToSection("fumigacion")}
              className="block w-full text-left py-2 hover:text-[#FF6B35] transition-colors"
            >
              Fumigación
            </button>
            <button
              onClick={() => scrollToSection("epp")}
              className="block w-full text-left py-2 hover:text-[#FF6B35] transition-colors"
            >
              EPP
            </button>
            <button
              onClick={() => scrollToSection("limpieza")}
              className="block w-full text-left py-2 hover:text-[#FF6B35] transition-colors"
            >
              Limpieza
            </button>
            <a
              href="https://wa.me/529841657527"
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full text-center bg-[#FF6B35] hover:bg-[#E55A24] px-4 py-2 rounded-lg font-semibold transition-colors mt-4"
            >
              WhatsApp
            </a>
          </nav>
        )}
      </header>

      {/* Hero Section */}
      <section className="relative min-h-screen md:h-screen flex items-center overflow-hidden">
        <img
          src="https://d2xsxph8kpxj0f.cloudfront.net/310519663631304412/TxDKBrEDNNKjajB8Fn3jCA/hero-security-branded-X49wX9JPeEN76si5sAquw6.webp"
          alt="Hero"
          className="absolute inset-0 w-full h-full object-cover object-center"
        />
        <div className="gradient-overlay"></div>
        <div className="container relative z-10 text-white py-16 md:py-0">
          <div className="max-w-2xl">
            <h1 className="font-display text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 md:mb-6 leading-tight">
              La seguridad es la calidad de tu empresa
            </h1>
            <p className="font-body text-base sm:text-lg md:text-xl lg:text-2xl mb-6 md:mb-8 text-gray-100">
              Soluciones integrales en Gestoría, Capacitación y Seguridad en Tulum y Riviera Maya
            </p>
            <div className="flex flex-col md:flex-row gap-4 mt-8">
              <a
                href="https://wa.me/529841657527"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-secondary text-center py-3 md:py-2 text-base md:text-sm min-h-[48px] md:min-h-auto flex items-center justify-center"
              >
                Cotiza sin compromiso
              </a>
              <button
                onClick={() => scrollToSection("gestoria")}
                className="btn-primary text-center py-3 md:py-2 text-base md:text-sm min-h-[48px] md:min-h-auto flex items-center justify-center"
              >
                Conoce nuestros servicios
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Gestoría Gubernamental */}
      <section id="gestoria" className="py-12 md:py-20 bg-white">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
            <div>
              <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-4 md:mb-6 text-[#001F3F]">
                Gestoría Gubernamental
              </h2>
              <p className="font-body text-lg text-gray-700 mb-8">
                Te ayudamos a gestionar tus trámites con eficiencia, rapidez y confianza.
              </p>
              <div className="space-y-4">
                {[
                  "Licencias de funcionamiento",
                  "Uso de suelo",
                  "Permisos ambientales",
                  "Anuncios y señalética",
                  "Regularización de trámites inconclusos",
                ].map((item, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className="w-8 h-8 bg-[#FF6B35] rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white font-bold">✓</span>
                    </div>
                    <p className="font-body text-gray-700">{item}</p>
                  </div>
                ))}
              </div>
            </div>
            <img
              src="/manus-storage/1000182930_cb28ec62.jpg"
              alt="Gestoría Gubernamental"
              className="rounded-lg shadow-lg"
            />
          </div>
        </div>
      </section>

      {/* Capacitación Certificada */}
      <section id="capacitacion" className="py-12 md:py-20 bg-gray-50">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
            <img
              src="/manus-storage/1000182936_1e0f8760.jpg"
              alt="Capacitación Certificada"
              className="rounded-lg shadow-lg w-full"
            />
            <div>
              <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-4 md:mb-6 text-[#001F3F]">
                Capacitación Certificada
              </h2>
              <p className="font-body text-lg text-gray-700 mb-8">
                Prepara a tu equipo con nuestros programas de capacitación profesional y certificada.
              </p>
              <div className="space-y-4">
                {[
                  "Primeros auxilios",
                  "Uso y manejo de extintores",
                  "Evacuación, búsqueda y Rescate",
                  "Seguridad e higiene",
                  "Asesoría para inspecciones",
                  "Salvamiento Acuático",
                ].map((item, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className="w-8 h-8 bg-[#FF6B35] rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white font-bold">✓</span>
                    </div>
                    <p className="font-body text-gray-700">{item}</p>
                  </div>
                ))}
              </div>
              <a
                href="https://wa.me/529841657527"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-secondary mt-8 inline-block"
              >
                Solicita capacitación
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Retardante de Fuego para Palapas */}
      <section id="fumigacion" className="py-12 md:py-20 bg-[#001F3F] text-white">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
            <div>
              <p className="text-[#FF6B35] font-semibold text-xs sm:text-sm tracking-widest mb-2">PROTECCIÓN ESPECIAL</p>
              <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-4 md:mb-6">
                Retardante de Fuego
              </h2>
              <p className="font-body text-lg mb-8 text-gray-100">
                Protege tu inversión en Tulum con nuestro tratamiento especializado de retardante de fuego para palapas y techos de palma.
              </p>
              <div className="space-y-6">
                <div className="bg-[#002850] p-6 rounded-lg">
                  <h3 className="font-heading text-xl font-bold mb-2">Protección de Inversión</h3>
                  <p className="font-body text-gray-200">
                    Aumenta la durabilidad y seguridad de tus estructuras.
                  </p>
                </div>
                <div className="bg-[#002850] p-6 rounded-lg">
                  <h3 className="font-heading text-xl font-bold mb-2">Prevención de Incendios</h3>
                  <p className="font-body text-gray-200">
                    Reduce significativamente el riesgo de propagación de fuego.
                  </p>
                </div>
              </div>
              <a
                href="https://wa.me/529841657527"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-secondary mt-8 inline-block"
              >
                Cotiza sin compromiso
              </a>
            </div>
            <img
              src="/manus-storage/1000182934_2c4c2155.jpg"
              alt="Fumigación"
              className="rounded-lg shadow-lg"
            />
          </div>
        </div>
      </section>

      {/* Seguridad y Extintores */}
      <section id="epp" className="py-12 md:py-20 bg-white">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
            <img
              src="/manus-storage/1000182953_61e93e57.jpg"
              alt="EPP"
              className="rounded-lg shadow-lg w-full"
            />
            <div>
              <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-4 md:mb-6 text-[#001F3F]">
                EPP
              </h2>
              <p className="font-body text-lg text-gray-700 mb-8">
                Equipo de Protección Personal (EPP) y soluciones de seguridad contra incendios con equipos 100% certificados.
              </p>
              <div className="space-y-4">
                {[
                  "Venta de extintores 100% certificados",
                  "Mantenimiento profesional",
                  "Recarga segura y efectiva",
                  "Detectores de humo acorde a la zona",
                  "Señaléticas con variedad de medidas",
                  "Botiquines con/sin equipamiento",
                  "Equipos de Protección Personal (chalecos, googles, guantes, etc.)",
                ].map((item, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className="w-8 h-8 bg-[#FF6B35] rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white font-bold">✓</span>
                    </div>
                    <p className="font-body text-gray-700">{item}</p>
                  </div>
                ))}
              </div>
              <a
                href="https://wa.me/529841657527"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-secondary mt-8 inline-block"
              >
                Solicita cotización
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Artículos de Limpieza y EPP */}
      <section id="limpieza" className="py-12 md:py-20 bg-gray-50">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
            <div>
              <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-4 md:mb-6 text-[#001F3F]">
                Artículos de Limpieza y EPP
              </h2>
              <p className="font-body text-lg text-gray-700 mb-8">
                Contamos con una amplia variedad de productos de calidad para la limpieza y protección de tu equipo.
              </p>
              <div className="grid grid-cols-2 gap-4">
                {[
                  "Paños de microfibra",
                  "Escobas",
                  "Cubrebocas",
                  "Guantes",
                  "Mechudos/trapeador",
                  "Cepillo de lavado de manos",
                  "Rollos de etiquetas",
                  "Productos de calidad",
                ].map((item, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <div className="w-6 h-6 bg-[#FF6B35] rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white font-bold text-sm">✓</span>
                    </div>
                    <p className="font-body text-gray-700">{item}</p>
                  </div>
                ))}
              </div>
              <a
                href="https://wa.me/529841657527"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-secondary mt-8 inline-block"
              >
                Ver catálogo
              </a>
            </div>
            <img
              src="/manus-storage/1000182944_44dc9d29.jpg"
              alt="Artículos de Limpieza y EPP"
              className="rounded-lg shadow-lg w-full"
            />
          </div>
        </div>
      </section>

      {/* Galería de Trabajos */}
      <section className="py-12 md:py-20 bg-gray-50">
        <div className="container">
          <div className="mb-8 md:mb-12">
            <p className="text-[#FF6B35] font-semibold text-xs sm:text-sm tracking-widest mb-2">NUESTROS TRABAJOS</p>
            <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#001F3F] mb-3 md:mb-4">
              Galería de <span className="text-[#FF6B35]">Proyectos</span>
            </h2>
            <p className="font-body text-lg text-gray-600 max-w-2xl">
              Conoce los proyectos que hemos realizado en Tulum. Fumigación, gestión de residuos, limpieza y más.
            </p>
          </div>

          {/* Filter Buttons */}
          <div className="flex flex-wrap gap-3 mb-12 justify-center">
            {['todos', 'fumigacion', 'residuos', 'limpieza', 'proyectos'].map((filter) => (
              <button
                key={filter}
                onClick={() => { setSelectedFilter(filter); setCurrentMediaIndex(0); }}
                className={`px-6 py-2 rounded-full font-semibold transition-all ${
                  selectedFilter === filter
                    ? 'bg-[#FF6B35] text-white'
                    : 'bg-white text-[#001F3F] border-2 border-[#001F3F] hover:bg-[#FF6B35] hover:text-white hover:border-[#FF6B35]'
                }`}
              >
                {filter.charAt(0).toUpperCase() + filter.slice(1)}
              </button>
            ))}
          </div>

          {/* Gallery Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {filteredItems.map((item, index) => (
              <div
                key={item.id}
                onClick={() => openModal(index)}
                className="relative group cursor-pointer rounded-lg overflow-hidden shadow-lg hover:shadow-2xl transition-all transform hover:scale-105 hover:translate-x-2"
                style={{
                  animation: `slideRight 20s infinite ease-in-out ${index * 0.5}s`
                }}
              >
                <style>{`
                  @keyframes slideRight {
                    0%, 100% { transform: translateX(0px); }
                    50% { transform: translateX(8px); }
                  }
                `}</style>
                {item.type === 'image' ? (
                  <img
                    src={item.src}
                    alt={item.title}
                    className="w-full h-64 object-cover group-hover:brightness-75 transition-all group-hover:translate-x-3"
                  />
                ) : (
                  <video
                    src={item.src}
                    className="w-full h-64 object-cover group-hover:brightness-75 transition-all group-hover:translate-x-3"
                  />
                )}
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/60 transition-all flex items-center justify-center">
                  <div className="text-white text-4xl">{item.type === 'video' ? '▶️' : '🔍'}</div>
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                  <p className="text-[#FF6B35] text-sm font-semibold uppercase tracking-wide">{item.category}</p>
                  <h3 className="text-white font-bold text-lg">{item.title}</h3>
                  <p className="text-gray-200 text-sm">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Modal */}
      {modalOpen && (
        <div
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
          onClick={closeModal}
        >
          <div className="relative w-full max-w-6xl" onClick={(e) => e.stopPropagation()}>
            {/* Contenedor principal */}
            <div className="relative" onClick={(e) => e.stopPropagation()}>
              <button
                onClick={closeModal}
                className="absolute -top-10 right-0 text-white text-3xl hover:text-[#FF6B35] transition-colors z-10"
              >
                ✕
              </button>
              {filteredItems[currentMediaIndex].type === 'image' ? (
                <img
                  src={filteredItems[currentMediaIndex].src}
                  alt={filteredItems[currentMediaIndex].title}
                  className="w-full h-auto rounded-lg object-contain"
                  style={{
                    maxWidth: '100%',
                    height: 'auto',
                    display: 'block'
                  }}
                />
              ) : (
                <video
                  src={filteredItems[currentMediaIndex].src}
                  controls
                  autoPlay
                  preload="metadata"
                  controlsList="nodownload"
                  className="w-full h-auto rounded-lg object-contain"
                  style={{
                    maxWidth: '100%',
                    height: 'auto',
                    display: 'block'
                  }}
                />
              )}
              <button
                onClick={() => {
                  const currentTitle = filteredItems[currentMediaIndex]?.title;
                  const relatedItems = filteredItems.filter(item => item.title === currentTitle);
                  const currentIndex = relatedItems.findIndex((item, idx) => 
                    filteredItems.indexOf(item) === currentMediaIndex
                  );
                  const prevIndex = currentIndex > 0 ? currentIndex - 1 : relatedItems.length - 1;
                  setCurrentMediaIndex(filteredItems.indexOf(relatedItems[prevIndex]));
                }}
                className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-16 text-white hover:text-[#FF6B35] transition-colors"
              >
                <ChevronLeft size={40} />
              </button>
              <button
                onClick={() => {
                  const currentTitle = filteredItems[currentMediaIndex]?.title;
                  const relatedItems = filteredItems.filter(item => item.title === currentTitle);
                  const currentIndex = relatedItems.findIndex((item, idx) => 
                    filteredItems.indexOf(item) === currentMediaIndex
                  );
                  const nextIndex = currentIndex < relatedItems.length - 1 ? currentIndex + 1 : 0;
                  setCurrentMediaIndex(filteredItems.indexOf(relatedItems[nextIndex]));
                }}
                className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-16 text-white hover:text-[#FF6B35] transition-colors"
              >
                <ChevronRight size={40} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Testimonios */}
      <section className="py-12 md:py-20 bg-white">
        <div className="container">
          <div className="mb-8 md:mb-12">
            <p className="text-[#FF6B35] font-semibold text-xs sm:text-sm tracking-widest mb-2">LO QUE DICEN NUESTROS CLIENTES</p>
            <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#001F3F] mb-3 md:mb-4">
              Testimonios de <span className="text-[#FF6B35]">Clientes</span>
            </h2>
            <p className="font-body text-lg text-gray-600 max-w-2xl">
              Conoce la experiencia de empresas que han confiado en nuestros servicios.
            </p>
          </div>

          {/* Testimonial Carousel */}
          <div className="relative max-w-3xl mx-auto">
            <div className="bg-gradient-to-r from-[#001F3F] to-[#002850] rounded-lg p-12 text-white">
              <div className="flex gap-1 mb-6">
                {[...Array(testimonials[currentTestimonial].rating)].map((_, i) => (
                  <Star key={i} size={20} fill="#FF6B35" color="#FF6B35" />
                ))}
              </div>
              <p className="font-body text-lg mb-6 italic">
                "{testimonials[currentTestimonial].text}"
              </p>
              <div className="border-t border-gray-400 pt-4">
                <p className="font-heading font-bold text-lg">{testimonials[currentTestimonial].name}</p>
                <p className="font-body text-gray-300">{testimonials[currentTestimonial].company}</p>
              </div>
            </div>

            {/* Navigation */}
            <button
              onClick={prevTestimonial}
              className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-16 text-[#001F3F] hover:text-[#FF6B35] transition-colors"
            >
              <ChevronLeft size={40} />
            </button>
            <button
              onClick={nextTestimonial}
              className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-16 text-[#001F3F] hover:text-[#FF6B35] transition-colors"
            >
              <ChevronRight size={40} />
            </button>

            {/* Dots */}
            <div className="flex justify-center gap-2 mt-8">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentTestimonial(index)}
                  className={`w-3 h-3 rounded-full transition-all ${
                    index === currentTestimonial ? 'bg-[#FF6B35] w-8' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Formulario de Contacto */}
      <section className="py-12 md:py-20 bg-gray-50">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <div className="mb-8 md:mb-12 text-center">
              <p className="text-[#FF6B35] font-semibold text-xs sm:text-sm tracking-widest mb-2">CONTACTO</p>
              <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#001F3F] mb-3 md:mb-4">
                Cotiza sin <span className="text-[#FF6B35]">Compromiso</span>
              </h2>
              <p className="font-body text-lg text-gray-600">
                Completa el formulario y nos pondremos en contacto contigo a través de WhatsApp.
              </p>
            </div>

            <form onSubmit={handleFormSubmit} className="bg-white rounded-lg shadow-lg p-8 md:p-12">
              {formSubmitted && (
                <div className="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
                  ✓ Mensaje enviado exitosamente. Nos contactaremos pronto.
                </div>
              )}

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block font-heading font-semibold text-[#001F3F] mb-2">Nombre *</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleFormChange}
                    required
                    className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-[#FF6B35] focus:outline-none transition-colors"
                    placeholder="Tu nombre"
                  />
                </div>
                <div>
                  <label className="block font-heading font-semibold text-[#001F3F] mb-2">Empresa *</label>
                  <input
                    type="text"
                    name="company"
                    value={formData.company}
                    onChange={handleFormChange}
                    required
                    className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-[#FF6B35] focus:outline-none transition-colors"
                    placeholder="Nombre de tu empresa"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block font-heading font-semibold text-[#001F3F] mb-2">Email *</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleFormChange}
                    required
                    className="w-full px-4 py-3 md:py-2 text-base md:text-sm border-2 border-gray-300 rounded-lg focus:border-[#FF6B35] focus:outline-none transition-colors"
                    placeholder="tu@email.com"
                  />
                </div>
                <div>
                  <label className="block font-heading font-semibold text-[#001F3F] mb-2">Teléfono *</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleFormChange}
                    required
                    className="w-full px-4 py-3 md:py-2 text-base md:text-sm border-2 border-gray-300 rounded-lg focus:border-[#FF6B35] focus:outline-none transition-colors"
                    placeholder="9841234567"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block font-heading font-semibold text-[#001F3F] mb-2">Servicio de Interés *</label>
                  <select
                    name="service"
                    value={formData.service}
                    onChange={handleFormChange}
                    required
                    className="w-full px-4 py-3 md:py-2 text-base md:text-sm border-2 border-gray-300 rounded-lg focus:border-[#FF6B35] focus:outline-none transition-colors"
                  >
                    <option value="">Selecciona un servicio</option>
                    <option value="Gestoría">Gestoría Gubernamental</option>
                    <option value="Capacitación">Capacitación Certificada</option>
                    <option value="Fumigación">Fumigación</option>
                    <option value="EPP">EPP</option>
                    <option value="Limpieza">Artículos de Limpieza y EPP</option>
                    <option value="Fumigación">Fumigación</option>
                  </select>
                </div>
                <div>
                  <label className="block font-heading font-semibold text-[#001F3F] mb-2">Presupuesto Estimado *</label>
                  <select
                    name="budget"
                    value={formData.budget}
                    onChange={handleFormChange}
                    required
                    className="w-full px-4 py-3 md:py-2 text-base md:text-sm border-2 border-gray-300 rounded-lg focus:border-[#FF6B35] focus:outline-none transition-colors"
                  >
                    <option value="">Selecciona un rango</option>
                    <option value="Menor a $5,000">Menor a $5,000</option>
                    <option value="$5,000 - $10,000">$5,000 - $10,000</option>
                    <option value="$10,000 - $25,000">$10,000 - $25,000</option>
                    <option value="Mayor a $25,000">Mayor a $25,000</option>
                  </select>
                </div>
              </div>

              <div className="mb-6">
                <label className="block font-heading font-semibold text-[#001F3F] mb-2">Mensaje *</label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleFormChange}
                  required
                  rows={5}
                  className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-[#FF6B35] focus:outline-none transition-colors"
                  placeholder="Cuéntanos más sobre tu proyecto..."
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#FF6B35] hover:bg-[#E55A24] text-white font-bold py-3 rounded-lg transition-colors"
              >
                Enviar Cotización por WhatsApp
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Google Maps */}
      <section className="py-12 md:py-20 bg-white">
        <div className="container">
          <div className="mb-8 md:mb-12 text-center">
            <p className="text-[#FF6B35] font-semibold text-xs sm:text-sm tracking-widest mb-2">UBICACIÓN</p>
            <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#001F3F] mb-3 md:mb-4">
              Visítanos en <span className="text-[#FF6B35]">Tulum</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-8">
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <div className="text-4xl mb-4">📍</div>
              <h3 className="font-heading font-bold text-[#001F3F] mb-2">Ubicación</h3>
              <p className="font-body text-gray-600">Tulum Centro, C.P. 77760, Quintana Roo, México</p>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <div className="text-4xl mb-4">🕐</div>
              <h3 className="font-heading font-bold text-[#001F3F] mb-2">Horarios</h3>
              <p className="font-body text-gray-600">Lunes a Viernes: 9:00 AM - 6:00 PM</p>
              <p className="font-body text-gray-600">Sábado: 9:00 AM - 2:00 PM</p>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <div className="text-4xl mb-4">📞</div>
              <h3 className="font-heading font-bold text-[#001F3F] mb-2">Contacto</h3>
              <p className="font-body text-gray-600">WhatsApp: 9841657527</p>
              <p className="font-body text-gray-600">Email: tramites13e@gmail.com</p>
            </div>
          </div>

          {/* Map Placeholder */}
          <div className="w-full h-96 bg-gray-200 rounded-lg flex items-center justify-center border-2 border-[#FF6B35]">
            <div className="text-center">
              <p className="text-gray-600 font-semibold mb-2">AYADA - Tulum Centro, C.P. 77760</p>
              <p className="text-gray-500 text-sm">Ubicación: Tulum, Riviera Maya</p>
              <p className="text-gray-500 text-sm mt-2">Horarios: Lunes a Viernes 9:00 AM - 6:00 PM</p>
              <p className="text-gray-500 text-sm">Sábado 9:00 AM - 2:00 PM</p>
            </div>
          </div>
        </div>
      </section>

      {/* Sección de Precios */}
      <section className="py-12 md:py-20 bg-white">
        <div className="container">
          <div className="mb-12 md:mb-16 text-center">
            <p className="text-[#FF6B35] font-semibold text-xs sm:text-sm tracking-widest mb-2">NUESTROS SERVICIOS</p>
            <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#001F3F] mb-3 md:mb-4">
              Planes y <span className="text-[#FF6B35]">Precios</span>
            </h2>
            <p className="font-body text-base sm:text-lg text-gray-600 max-w-2xl mx-auto">
              Soluciones adaptadas a tu presupuesto y necesidades empresariales
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {/* Gestoría */}
            <div className="bg-gray-50 rounded-lg p-8 hover:shadow-xl transition-all border-2 border-gray-200 hover:border-[#FF6B35]">
              <h3 className="text-2xl font-bold text-[#001F3F] mb-2">Gestoría</h3>
              <p className="text-[#FF6B35] font-bold text-3xl mb-6">Consultar</p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-2"><span className="text-[#FF6B35] font-bold">✓</span> Licencias de funcionamiento</li>
                <li className="flex items-start gap-2"><span className="text-[#FF6B35] font-bold">✓</span> Permisos ambientales</li>
                <li className="flex items-start gap-2"><span className="text-[#FF6B35] font-bold">✓</span> Trámites inconclusos</li>
              </ul>
              <a href="https://wa.me/529841657527" target="_blank" rel="noopener noreferrer" className="w-full bg-[#001F3F] text-white py-2 rounded-lg hover:bg-[#FF6B35] transition-colors text-center font-semibold">Cotizar</a>
            </div>

            {/* Capacitación */}
            <div className="bg-gray-50 rounded-lg p-8 hover:shadow-xl transition-all border-2 border-gray-200 hover:border-[#FF6B35]">
              <h3 className="text-2xl font-bold text-[#001F3F] mb-2">Capacitación</h3>
              <p className="text-[#FF6B35] font-bold text-3xl mb-6">$2,500+</p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-2"><span className="text-[#FF6B35] font-bold">✓</span> Primeros auxilios</li>
                <li className="flex items-start gap-2"><span className="text-[#FF6B35] font-bold">✓</span> Combate incendios</li>
                <li className="flex items-start gap-2"><span className="text-[#FF6B35] font-bold">✓</span> Evacuación</li>
              </ul>
              <a href="https://wa.me/529841657527" target="_blank" rel="noopener noreferrer" className="w-full bg-[#FF6B35] text-white py-2 rounded-lg hover:bg-[#001F3F] transition-colors text-center font-semibold">Agendar</a>
            </div>

            {/* Fumigación */}
            <div className="bg-gray-50 rounded-lg p-8 hover:shadow-xl transition-all border-2 border-gray-200 hover:border-[#FF6B35]">
              <h3 className="text-2xl font-bold text-[#001F3F] mb-2">Fumigación</h3>
              <p className="text-[#FF6B35] font-bold text-3xl mb-6">$1,500+</p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-2"><span className="text-[#FF6B35] font-bold">✓</span> Control de plagas</li>
                <li className="flex items-start gap-2"><span className="text-[#FF6B35] font-bold">✓</span> Certificado oficial</li>
                <li className="flex items-start gap-2"><span className="text-[#FF6B35] font-bold">✓</span> Seguimiento</li>
              </ul>
              <a href="https://wa.me/529841657527" target="_blank" rel="noopener noreferrer" className="w-full bg-[#001F3F] text-white py-2 rounded-lg hover:bg-[#FF6B35] transition-colors text-center font-semibold">Solicitar</a>
            </div>
          </div>
        </div>
      </section>

      {/* Sección de Certificaciones *      {/* Certificaciones */}
      <section className="py-12 md:py-20 bg-[#001F3F] text-white">
        <div className="container">
          <div className="mb-8 md:mb-12 text-center">
            <p className="text-[#FF6B35] font-semibold text-xs sm:text-sm tracking-widest mb-2">CERTIFICACIONES</p>
            <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-3 md:mb-4">
              Acreditaciones <span className="text-[#FF6B35]">Oficiales</span>
            </h2>
            <p className="font-body text-base sm:text-lg text-gray-300 max-w-2xl mx-auto">
              Contamos con todas las acreditaciones necesarias para garantizar calidad y seguridad
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 items-center justify-items-center">
            <div className="text-center">
              <div className="bg-white rounded-lg p-6 mb-3 w-20 h-20 flex items-center justify-center">
                <span className="text-3xl">📋</span>
              </div>
              <p className="text-white font-semibold">NOM</p>
              <p className="text-gray-300 text-sm">Normativa Oficial</p>
            </div>
            <div className="text-center">
              <div className="bg-white rounded-lg p-6 mb-3 w-20 h-20 flex items-center justify-center">
                <span className="text-3xl">✓</span>
              </div>
              <p className="text-white font-semibold">FIRA</p>
              <p className="text-gray-300 text-sm">Certificación</p>
            </div>
            <div className="text-center">
              <div className="bg-white rounded-lg p-6 mb-3 w-20 h-20 flex items-center justify-center">
                <span className="text-3xl">🛡️</span>
              </div>
              <p className="text-white font-semibold">ISO</p>
              <p className="text-gray-300 text-sm">Estándares</p>
            </div>
            <div className="text-center">
              <div className="bg-white rounded-lg p-6 mb-3 w-20 h-20 flex items-center justify-center">
                <span className="text-3xl">🔒</span>
              </div>
              <p className="text-white font-semibold">Seguridad</p>
              <p className="text-gray-300 text-sm">Garantizada</p>
            </div>
          </div>
        </div>
      </section>

      {/* Sección de Blog/Recursos */}
      <section className="py-12 md:py-20 bg-gray-50">
        <div className="container">
          <div className="mb-8 md:mb-12 text-center">
            <p className="text-[#FF6B35] font-semibold text-xs sm:text-sm tracking-widest mb-2">CONOCIMIENTO</p>
            <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#001F3F] mb-3 md:mb-4">
              Centro de <span className="text-[#FF6B35]">Recursos</span>
            </h2>
            <p className="font-body text-base sm:text-lg text-gray-600 max-w-2xl mx-auto">
              Aprende sobre seguridad, normativas y mejores prácticas para tu empresa
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            <div className="bg-white rounded-lg p-8 shadow-lg hover:shadow-xl transition-all">
              <div className="text-4xl mb-4">🔥</div>
              <h3 className="text-xl font-bold text-[#001F3F] mb-3">Prevención de Incendios</h3>
              <p className="text-gray-600 mb-4">Guía completa sobre cómo proteger tu negocio con retardante de fuego y equipos de seguridad certificados.</p>
              <a href="https://wa.me/529841657527" className="text-[#FF6B35] font-semibold hover:text-[#001F3F]">Más información →</a>
            </div>
            <div className="bg-white rounded-lg p-8 shadow-lg hover:shadow-xl transition-all">
              <div className="text-4xl mb-4">📚</div>
              <h3 className="text-xl font-bold text-[#001F3F] mb-3">Normativas Vigentes</h3>
              <p className="text-gray-600 mb-4">Mantente actualizado con las normativas NOM y requisitos legales para empresas en Tulum y Riviera Maya.</p>
              <a href="https://wa.me/529841657527" className="text-[#FF6B35] font-semibold hover:text-[#001F3F]">Más información →</a>
            </div>
            <div className="bg-white rounded-lg p-8 shadow-lg hover:shadow-xl transition-all">
              <div className="text-4xl mb-4">👥</div>
              <h3 className="text-xl font-bold text-[#001F3F] mb-3">Capacitación Continua</h3>
              <p className="text-gray-600 mb-4">Programas de entrenamiento certificado para tu equipo en primeros auxilios, evacuación y seguridad laboral.</p>
              <a href="https://wa.me/529841657527" className="text-[#FF6B35] font-semibold hover:text-[#001F3F]">Más información →</a>
            </div>
          </div>
        </div>
      </section>

      {/* Fumigación */}
      <section className="py-12 md:py-20 bg-gradient-to-r from-[#001F3F] via-[#002850] to-[#001F3F]">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
            <img
              src="/manus-storage/1000182931_12f16e1b.jpg"
              alt="Venta, Mantenimiento y Recarga de Extintores"
              className="rounded-lg shadow-2xl w-full"
            />
            <div className="text-white">
              <h2 className="font-display text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 md:mb-6 text-[#FF6B35]">
                Servicio de Fumigación
              </h2>
              <p className="font-body text-base sm:text-lg md:text-xl mb-6 md:mb-10 text-gray-100 leading-relaxed">
                Control de plagas con certificado oficial. Protege tu negocio y a tus clientes con nuestro servicio profesional de fumigación.
              </p>
              <a
                href="https://wa.me/529841657527?text=Hola%20AYADA%2C%20me%20interesa%20el%20servicio%20de%20fumigaci%C3%B3n"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-[#FF6B35] text-white font-bold text-lg py-4 px-10 rounded-lg hover:bg-[#E55A24] transition-all duration-300 transform hover:scale-110 shadow-2xl border-2 border-[#FF6B35] hover:border-[#E55A24]"
              >
                ✓ Solicita servicio de fumigación
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Botón Flotante WhatsApp */}
      <a
        href="https://wa.me/529841657527"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 bg-[#25D366] text-white rounded-full p-4 shadow-2xl hover:bg-[#1EBD59] transition-all transform hover:scale-110 md:block hidden"
        title="Contactar por WhatsApp"
      >
        <MessageCircle size={28} />
      </a>

      {/* Botón Flotante WhatsApp para Móvil */}
      <a
        href="https://wa.me/529841657527"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 bg-[#25D366] text-white rounded-full p-4 shadow-2xl hover:bg-[#1EBD59] transition-all transform hover:scale-110 md:hidden"
        title="Contactar por WhatsApp"
      >
        <MessageCircle size={24} />
      </a>

      {/* Footer */}
      <footer className="bg-[#001F3F] text-white py-12">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-12 mb-12">
            {/* Company Info */}
            <div>
              <img src="/manus-storage/ayada-logo_c919adb7.jpg" alt="AYADA Logo" className="h-16 w-auto mb-4" />
              <p className="font-body text-gray-300">
                Asesoría y Análisis de Alimentos
              </p>
              <p className="font-body text-gray-300 mt-2">
                La seguridad es la calidad de tu empresa
              </p>
            </div>

            {/* Contact Info */}
            <div>
              <h3 className="font-heading text-lg font-bold mb-4">Contacto</h3>
              <div className="space-y-3">
                <a
                  href="https://wa.me/529841657527"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 hover:text-[#FF6B35] transition-colors"
                >
                  <MessageCircle size={18} />
                  <span className="font-body">9841657527</span>
                </a>
                <a
                  href="tel:+529841657527"
                  className="flex items-center gap-2 hover:text-[#FF6B35] transition-colors"
                >
                  <Phone size={18} />
                  <span className="font-body">9841657527</span>
                </a>
                <a
                  href="mailto:tramites13e@gmail.com"
                  className="flex items-center gap-2 hover:text-[#FF6B35] transition-colors"
                >
                  <Mail size={18} />
                  <span className="font-body">tramites13e@gmail.com</span>
                </a>
              </div>
            </div>

            {/* Social Media */}
            <div>
              <h3 className="font-heading text-lg font-bold mb-4">Síguenos</h3>
              <div className="space-y-3">
                <a
                  href="https://www.facebook.com/share/14daWmncK1k/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 hover:text-[#FF6B35] transition-colors"
                >
                  <Facebook size={18} />
                  <span className="font-body">Facebook</span>
                </a>
                <a
                  href="https://www.instagram.com/a.y.a.d.a_gestoria?igsh=MjF5c2dvOXVvdGEz"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 hover:text-[#FF6B35] transition-colors"
                >
                  <Instagram size={18} />
                  <span className="font-body">Instagram</span>
                </a>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-700 pt-8">
            <p className="font-body text-center text-gray-400">
              © 2026 AYADA - Asesoría y Análisis de Alimentos. Todos los derechos reservados. | Ubicados en Tulum, Riviera Maya
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
